# GUVA-S12SD-lib
This is a library for the GUVA S12SD UV Sensor.
